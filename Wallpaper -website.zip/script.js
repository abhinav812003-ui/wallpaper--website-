function goPremium() {
  window.location.href = "premium.html";
}